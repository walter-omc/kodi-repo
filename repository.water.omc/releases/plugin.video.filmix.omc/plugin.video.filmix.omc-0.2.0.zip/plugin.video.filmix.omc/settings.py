# -*- coding: utf-8 -*-
#очистка кеша

import sys, xbmc, xbmcaddon
from core.defines import *
sys.argv[0] = PLUGIN_ID
import os

