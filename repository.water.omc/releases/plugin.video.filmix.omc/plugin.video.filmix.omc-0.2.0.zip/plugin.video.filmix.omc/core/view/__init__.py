#!/usr/bin/env python
# coding: utf-8
# vim:fenc=utf-8:ts=2:tw=80

#
# Copyright © 2017 weirdgiraffe <giraffe@cyberzoo.xyz>
#
# Distributed under terms of the MIT license.
#


